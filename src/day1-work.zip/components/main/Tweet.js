import React from 'react'

function Tweet(props) {
    return (
        <div>
            <h4> {props.data.title} </h4>
        </div>
    )
}

export default Tweet
